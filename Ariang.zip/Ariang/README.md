Aria2 - CLI Metalink/BitTorrent Client
========

文件说明
--------
    Aria2Data     # 下载目录 默认下载文件会保存在这里
    aria2.conf    # 配置文件 可以自己根据说明修改
    aria2.exe     # 启动文件 使用这个来启动 aria2
    aria2.session # 任务保存文件 未完成任务会保存在这里
    aria2c.exe    # 命令行主程序
    README.md     # README
